#include <iostream>
#include <string>
#include <fstream>

#include "Otodu(Azlin).h"

// #include "loginOtodu(Anugrah).h"
// #include "daftarOtodu(Hana).h"
// #include "AntrianSiswa(hana).h"
// #include "daftarOtoduSiswa(Yazid).h"
// #include "konfirBeli(Edwin).h"
// #include "MatematikaOtodu(Shafda).h"
// #include "mentorAdam(Azlin).h"
// #include "mentorOtodu(yazid).h"



int main() {
    otodu();

}
