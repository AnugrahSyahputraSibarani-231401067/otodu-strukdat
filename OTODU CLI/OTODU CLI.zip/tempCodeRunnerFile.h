cin.ignore();
    getch();
    cout << "\nKetik apapun untuk kembali";
    siswaOtodu();